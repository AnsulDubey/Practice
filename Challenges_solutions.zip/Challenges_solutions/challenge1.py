
"""
implement function 'subtract_months' to subtract 'n' number of months from a given year and month.

Inputs: Is a list of tuples [(year1, month1, months_to_subtract1), (year2, month2, months_to_subtract2), ...]
where, year is a 4 digit integer
month is an interger value between 1 to 12, 1=January, 2=February, ... 12=December) and
months_to_subtract is an integer

Output: Is a list of tuples [(result_year1, result_month1), (result_year2, result_month2), ...]
year (4 digit integer) month (interger value between 1 to 12, 1=January, 2=February, ... 12=December)

For example: subtract 3 months from May 2020. This should result in an output Feb 2020
In this example inputs: year=2020 month=5
output: year=2020 month=2

Code evaluation criteria:
1. Correctness for all possible cases
2. Code should be clean and readable
3. optimal with respect to time and space complexity (e.g. avoid unnecessary extra variables and loops)

"""
# assumed that input data year month and subtracted months are in right logical form and there is no discrepancy in data
# information  for the case when months and months to be subtracted is same, is not given so in this case I kept it as 0 month


def subtract_months(input_list):

    output_list = [(item[0] - 1, 12 + item[1] - item[2]) if item[1] < item[2] else (item[0], item[1] - item[2]) for item in input_list]

    return output_list
