"""
Pandas programming task

1. Load the data into a Pandas dataframe
2. Remove records where scheme_code is NULL
3. Sort the data by nav_date
4. Fill Missing values in nav column by the last known value in the field after sorting by nav_date (Fill forward)
5. Save the output dataframe with the name pandas_challenge_output.csv
6. Send output file as well as the code in a zip file

Code evaluation criteria:
1. Correctness of the output file and code
2. Code should be clean and readable
3. optimal with respect to time and space complexity (e.g. avoid unnecessary extra variables and loops)

"""
import pandas as pd


def process_df(input_csv):
    df = pd.read_csv(input_csv)
    df = df.dropna(subset=["scheme_code"], axis=0)
    df["nav_date"] = pd.to_datetime(df["nav_date"])
    df.sort_values(by='nav_date', axis=0, inplace=True)
    df['nav'].fillna(method='ffill', inplace=True)
    df.to_csv('pandas_challenge_output.csv')


process_df("challenge2_input.csv")
